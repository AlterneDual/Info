package com.example.prueba

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.fragment.navArgs
import com.example.prueba.inicioBlankFragmentDirections.ActionInicioBlankFragmentToBlankFragment1

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"


class inicioBlankFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    val args: inicioBlankFragmentArgs by navArgs()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        var vista = inflater.inflate(R.layout.fragment_inicio_blank, container, false)

        Toast.makeText(activity, args.textoEjemplo, Toast.LENGTH_LONG).show()

        return vista
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val navController: NavController = Navigation.findNavController(view)

        val btn = view.findViewById<View>(R.id.button)
        val btn2 = view.findViewById<View>(R.id.button2)
        btn.setOnClickListener(View.OnClickListener {

            inicioBlankFragmentDirections.actionInicioBlankFragmentToBlankFragment1("me cago en la leche")

            Navigation.findNavController(view).navigate(R.id.blankFragment1)


        })
        btn2.setOnClickListener(View.OnClickListener {

            navController.navigate(R.id.blankFragment2)

        })
    }

    companion object {

        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            inicioBlankFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}