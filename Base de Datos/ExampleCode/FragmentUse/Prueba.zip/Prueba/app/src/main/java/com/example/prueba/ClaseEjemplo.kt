package com.example.prueba

class ClaseEjemplo(var id:Int, var nombre:String, var apellido:String, var edad:Int, var dni:String, var telefono:String, var email:String, var direccion:String, var ciudad:String, var provincia:String, var pais:String, var codigoPostal:String, var fechaNacimiento:String, var fechaAlta:String, var fechaBaja:String, var estado:Boolean, var usuario:String, var password:String, var rol:String){
}
